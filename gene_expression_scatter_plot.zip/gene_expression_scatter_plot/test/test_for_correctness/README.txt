[Test case]
N1_n0_S5_info_miss_rate0.00_g1.json
N1_n0_S5_info_miss_rate0.00_g2.json
N1_n0_S5_info_miss_rate0.00_info.json

    correlation coefficient = 0.8109276
    p-value (two-sided) = 0.0958426


[Test case]
N1_n0_S10_info_miss_rate0.00_g1.json
N1_n0_S10_info_miss_rate0.00_g2.json
N1_n0_S10_info_miss_rate0.00_info.json

    correlation coefficient = 0.968265
    p-value (two-sided) = 4.270696e-06


[Test case]
N2_n1_S10_info_miss_rate0.00_g1.json
N2_n1_S10_info_miss_rate0.00_g2.json
N2_n1_S10_info_miss_rate0.00_info.json

    correlation coefficient (all points) = 0.01349347
    p-value (two-sided) = 0.9704884

